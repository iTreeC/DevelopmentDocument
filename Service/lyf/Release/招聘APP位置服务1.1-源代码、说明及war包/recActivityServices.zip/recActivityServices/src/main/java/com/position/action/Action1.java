package com.position.action;

import com.opensymphony.xwork2.ActionSupport;
/**
 * （测试用）暂时保留，整理结构
 * @author Fei
 *
 */
public class Action1 extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return SUCCESS;
	}
}
